


function validLoan(loan)
{
	  if(loan.length==0)
	  {
		  alert("loan should not be empty");
		  return false;
	  }
	
	  if(loan<=0)
     {
	  alert("loan should not zero");
	  return false;
	   }
	  if(isNaN(loan))
	  {
		  alert("loan should only digits");
		  return false;
	  }
	
	 if(loan>1500000)
	 {
		 alert("loan should not greater than 15Lk");
	  return false;
	 }
	 
	
}

function validRate(rate)
{
	
	 if(rate.length==0)
	  {
		  alert("rate should not be empty");
		  return false;
	  }
	 
	  if(isNaN(rate)|| rate<=0)
	  {
		  alert("rate should only digits greater than 0");
		  return false;
	  }
	
}

function validRepay(repay)
{
	
	 if(repay.length==0)
	  {
		  alert("repay should not be empty");
		  return false;
	  }
	 
	  if(repay<7 || repay>15 || isNaN(repay))
	  {
		  alert("repay should only digits between 7 to 15");
		  return false;
	  }
	
}
function calculate()
{
	
	var loan=window.document.form1.txtamt.value;
var rate=window.document.form1.txtper.value;
var repay=window.document.form1.txtrepay.value;


	var totint=(loan*repay*rate)/100;
	
	var totpay=eval(loan)+eval(totint);
	var mntypay=totpay/(rate*12);
	
	window.document.form1.txtmntly.value=mntypay;
	window.document.form1.txttot.value=totpay;
    window.document.form1.txttotin.value=totint;
}

