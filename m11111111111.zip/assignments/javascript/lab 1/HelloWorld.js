function sayHello(){
document.write('<h1 align="right">Hello World!</h1>');
}