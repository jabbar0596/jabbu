package com.cg.junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.bean.Book;
import com.cg.service.BookCollectionHelper;

public class TestBook {

    static BookCollectionHelper bookSet;
    static Book book;
	

	@Before
	public void init()
	{
		bookSet=new BookCollectionHelper();
		book=new Book();

	}
	
	@After
	public void destroy()
	{
		bookSet=null;
		book = null;
	}
    
	//testing number of records present initially
	@Test
	public void testGetTotalBookCount() 
	{
		assertTrue(bookSet.getTotalBookCount() == 5);
	}

	//testing number of records present after adding an book object to hashset 
	@Test
	public void testAddBookDetails()
	{
		int len=bookSet.getTotalBookCount();
		book.setBookId(1234);
		book.setBookName("Java");
		book.setBookPrice(300.00f);
		bookSet.addBookDetail(book);
		
		assertTrue(bookSet.getTotalBookCount()>len);
		
	}
	
	//negative test case for the above two test
	@Test
	public void negativeTestGetTotalBookCount() 
	{
		assertNotSame(bookSet.getTotalBookCount() , 4);
	}

	@Test
	public void negativeTestAddBookDetails()
	{
		int len=bookSet.getTotalBookCount();
		book.setBookId(1234);
		book.setBookName("Java");
		book.setBookPrice(300.00f);
		bookSet.addBookDetail(book);
		
		assertNotSame(bookSet.getTotalBookCount(),len);
		
	}
	
	//testing getter and setter methods
	@Test
	public void testGetBookId(){
		
		book.setBookId(123);
		assertEquals(123,book.getBookId());
		
	}
	
	@Test
	public void testGetBookName(){
		
		book.setBookName("Java");
		assertEquals("Java",book.getBookName());
		
	}
	
	@Test
	public void testGetBookPrice(){
		float val=123.00f;
		book.setBookPrice(val);
		assertTrue(book.getBookPrice()==val);
		
	}

	//negative test for getter and setter methods
	@Test
	public void negativeTestGetBookId(){
		
		book.setBookId(123);
		assertNotSame(124,book.getBookId());
		
	}
	
	@Test
	public void negativeTestGetBookName(){
		
		book.setBookName("Java");
		assertNotSame("JAVA",book.getBookName());
		
	}
	
	@Test
	public void negativeTestGetBookPrice(){
		float val=123.00f;
		book.setBookPrice(val);
		assertNotSame(book.getBookPrice(),val);
		
	}

	
	

}
