package com.cg.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.cg.exception.BookException;

public class BookValidater {

	// Method validating choice value
	public boolean isValidChoice(String ch) throws BookException
	{
		boolean flag=false;
		
		Pattern pat=Pattern.compile("^[0-9]{1}$");
		Matcher mat=pat.matcher(ch);
		if(!mat.find())
		{
			throw new BookException("Error:Choice should be 1 digits format only");
		}
		return flag;
	}

	// Method validating book id value	
	public boolean isValidBookId(String bookId)throws BookException{
		boolean flag=false;

		
		Pattern pat = Pattern.compile("^[0-9]{3}$");
		Matcher mat= pat.matcher(bookId);
		if(!mat.find()){
			
			throw new BookException("Error:Book should be three digits format only");
			
		}
		
		return flag;

	}
	
	
	
	// Method validating book name value
	public boolean isValidBookName(String bookName)throws BookException{
		boolean flag=false;

		
		Pattern pat = Pattern.compile("^[[\\s]*[\\S]*]{5,50}$");
		//"^ [\\w-]*$"
		//("^[A-Za-z0-9]{5,20}$");
		Matcher mat= pat.matcher(bookName);
		if(!mat.find()){
			
			throw new BookException("Error:Book name should be alphanumeric format");
			
		}
		
		return flag;

	}

	// Method validating book price value
	public boolean isValidBookPrice(String bookPrice)throws BookException{
		boolean flag=false;

		
		Pattern pat = Pattern.compile("^[0-9]{0,9}.[0-9]{0,2}$");
		Matcher mat= pat.matcher(bookPrice);
		if(!mat.find()){
			
			throw new BookException("Error:Book price should be in float(decimal) format only");
			
		}
	
		if(Float.parseFloat(bookPrice) > 1000.00f){
			
			throw new BookException("Error:Book price should not be more than 1000Rs");
			
		}
		
		return flag;

	}

	
	
}
