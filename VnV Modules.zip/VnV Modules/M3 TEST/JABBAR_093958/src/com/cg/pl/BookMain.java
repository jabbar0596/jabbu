package com.cg.pl;

//importing necessary files
import java.util.Scanner;
import com.cg.bean.Book;
import com.cg.exception.BookException;
import com.cg.service.BookCollectionHelper;
import com.cg.service.BookValidater;


public class BookMain {

	static Scanner scan = new Scanner(System.in);
	static BookValidater val = new BookValidater();
	static BookMain bookmain=new BookMain();
	static Book book;
    static String	id=null;
    static String	name=null;
    static String	price=null;
    
	public static void main(String[] args) {
     	//  calling main menu	
		bookmain.menu();

	}


	
	public void menu(){
		
		
		String ch = null ;
		//accepting and validating choice value
		while(true){
		try{
			
		
		System.out.println("1.To add new Book Details");
		System.out.println("2.To get total number of Books");
		System.out.println("3.Exit");
		System.out.println("Enter your choice(1,2,3): ");
        ch=scan.next();
        val.isValidChoice(ch);
		}
		catch(BookException exp){
			System.err.println(exp.getMessage());
			continue;
		}
		break;
		}
		
		

        //execute the menu option according to menu options 
		switch (ch)
		{
		case "1":
			addBookRecords();
			break;
			
		case "2":
			int count= new BookCollectionHelper().getTotalBookCount();
			System.out.println("Total number of book details are :"+count);
			break;
			
		case "3":
			System.out.println("-----Exit-----");
			break;
			
		default:
			System.err.println("Please enter the correct choice");
		}
		
		System.out.println("\n\n---------------------------------");
		if(Integer.parseInt(ch) !=3 )
		{
		menu();
		}
	}

    //   adding book records
	public void addBookRecords() {

		String num=null;
		
		while(true){
		try{
			System.out.println("please enter how many Book details you want to add");
			num=scan.next();
	
		val.isValidChoice(num);
		}
		catch(BookException exp){
			System.err.println(exp.getMessage());
			continue;
		}
		break;
		}
		
		int num1=Integer.parseInt(num);
		
		while(num1>0)
			{

		System.out.println("Enter the following details:");


		int bookId = Integer.parseInt(acceptBookId());
		String bookName = acceptBookName();
		float bookPrice = Float.parseFloat(acceptBookPrice());

		book =new Book(bookId,bookName,bookPrice);
		
		
		new BookCollectionHelper().addBookDetail(book);

		System.out.println("Book detail added successfully");
		System.out.println(book);

		num1--;
		}
		
		System.out.println(num+" books are added");

		
		
	}

	//accepting  book Id from user and validate it
	private String acceptBookId() {
		
		System.out.println("Enter Book Id:");
        id=scan.next();
	
	try{
		val.isValidBookId(id);
		
	}
	catch(BookException exp){
		
		System.err.println(exp.getMessage());
		acceptBookId();
	}
	return id;

	}

	//accepting  book Name from user and validate it
	private String acceptBookName() {


		System.out.println("Enter Book Name:");
        name=scan.nextLine();

	
	try{
		val.isValidBookName(name);
		
	}
	catch(BookException exp){
		
		System.err.println(exp.getMessage());
		acceptBookName();
	}
	return name;

	}

	//accepting  book Price from user and validate it	
	private String acceptBookPrice() {
		
		System.out.println("Enter Book Price:");
        price=scan.next();
	
	try{
		val.isValidBookPrice(price);
		
	}
	catch(BookException exp){
		
		System.err.println(exp.getMessage());
		acceptBookPrice();
	}
	return price;

	}

}
