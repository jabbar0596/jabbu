package com.cg.exception;

public class BookException extends Exception {

	
	//Creating BookExcpetion
	
	public BookException(String message)
	{
		super(message);
	}

}

	
